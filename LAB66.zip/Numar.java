public class Numar {
    private int numar;

    public Numar(int numar) {
        this.numar = numar;
    }

    public int getNumar() {
        return numar;
    }

    public void setNumar(int numar) {
        this.numar = numar;
    }

    public int suma(int a) {
        return numar + a;
    }

    public int suma(int a, int b) {
        return numar + a + b;
    }

    public int suma(int a, int b, int c) {
        return numar + a + b + c;
    }

    public int suma(int a, int b, int c, int d) {
        return numar + a + b + c + d;
    }

    public static void main(String[] args) {
        Numar n = new Numar(10);
        System.out.println(n.suma(5));  // afisare: 15
        System.out.println(n.suma(2, 3));  // afisare: 15
        System.out.println(n.suma(1, 2, 3));  // afisare: 16
        System.out.println(n.suma(1, 2, 3, 4));  // afisare: 20
    }
}