public class Fractie {
    private int numarator;
    private int numitor;

    public Fractie() {
        this.numarator = 0;
        this.numitor = 1;
    }

    public Fractie(int numarator, int numitor) {
        this.numarator = numarator;
        this.numitor = numitor;
    }

    public int getNumarator() {
        return numarator;
    }

    public void setNumarator(int numarator) {
        this.numarator = numarator;
    }

    public int getNumitor() {
        return numitor;
    }

    public void setNumitor(int numitor) {
        this.numitor = numitor;
    }

    public Fractie adunare(Fractie f2) {
        int numitorComun = this.numitor * f2.numitor;
        int numarator1 = this.numarator * f2.numitor;
        int numarator2 = f2.numarator * this.numitor;
        int suma = numarator1 + numarator2;
        Fractie rezultat = new Fractie(suma, numitorComun);
        return rezultat;
    }

    @Override
    public String toString() {
        return numarator + "/" + numitor;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Fractie) {
            Fractie f = (Fractie) obj;
            return this.numarator * f.numitor == this.numitor * f.numarator;
        }
        return false;
    }

    public static void main(String[] args) {
        Fractie f1 = new Fractie(1, 2);
        Fractie f2 = new Fractie(3, 4);
        Fractie f3 = f1.adunare(f2);

        System.out.println("f1 = " + f1.toString());
        System.out.println("f2 = " + f2.toString());
        System.out.println("f3 = " + f3.toString());

        System.out.println("f1 egal cu f2: " + f1.equals(f2));
        System.out.println("f2 egal cu f3: " + f2.equals(f3));
    }
}