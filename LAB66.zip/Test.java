// Clasa Test
public class Test {
    public static void main(String[] args) {
        Punct A = new Punct(1, 2);
        Punct B = new Punct(-1, 3);

        System.out.println("Distanta dintre punctele A" + A.toString() + " si B" + B.toString() + " este " + A.distance(B));
    }
}