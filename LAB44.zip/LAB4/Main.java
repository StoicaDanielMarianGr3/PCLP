import java.util.Arrays;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {


        // EXERCITIUL 1111111111111111111111


        int numar;
        Scanner nr = new Scanner(System.in);

        System.out.println("introdu numarul de elemente dorit");


        numar = nr.nextInt();

        int[] afis = new int[numar];


        System.out.println("Introduceti " + numar + " elemente");

        int i;

        for (i = 0; i < numar; i++) {

            afis[i] = nr.nextInt();

        }


        Arrays.toString(afis);

        int size = afis.length;

        int numar2 = afis[size - 2];

        System.out.println("Al doilea cel mai mare nuamr :" + numar2);

        // EXERCITIUL 222222222222222222222


        int[][] matricea1 = {{1, 2, 3, 4},
                {5, 6, 7, 8},
                {9, 10, 11, 12}};

        int[][] matricea2 = {{13, 14, 15, 16},
                {17, 18, 19, 20},
                {21, 22, 23, 24}};

        int[][] RezultatMatrice = new int[3][4];

        for (int k = 0; k < 3; k++) {
            for (int l = 0; l < 4; l++) {
                RezultatMatrice[k][l] = matricea1[k][l] + matricea2[k][l];
            }
        }

        System.out.println("Rezultatil Matricei:");
        for (int k = 0; k < 3; k++) {
            for (int l = 0; l < 4; l++) {
                System.out.print(RezultatMatrice[k][l] + " ");
            }
            System.out.println();
        }

    }
}