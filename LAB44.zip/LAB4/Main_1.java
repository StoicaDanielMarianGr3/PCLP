import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Introduceți numărul de elemente: ");
        int n = scanner.nextInt();

        int[] arr = new int[n];
        System.out.println("Introduceți elementele:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        int lungimeNoua = eliminareDuplicate(arr);
        System.out.println("Noua lungime a matricei: " + lungimeNoua);
    }

    public static int eliminareDuplicate(int[] arr) {
        Set<Integer> set = new HashSet<>();

        for (int element : arr) {
            set.add(element);
        }

        return set.size();
    }
}