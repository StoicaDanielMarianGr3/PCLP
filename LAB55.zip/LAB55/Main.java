import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Main {

    //////// EXERCITIUL 1111111111111
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduceți o parolă:");
        String parola = scanner.nextLine();
        scanner.close();

        // Verificarea lungimii parolei
        if (parola.length() < 8) {
            System.out.println("Parolă invalidă: Parola trebuie să conțină cel puțin 8 caractere.");
            return;
        }

        // Verificarea prezenței spațiilor
        if (parola.contains(" ")) {
            System.out.println("Parolă invalidă: Parola nu trebuie să conțină spații.");
            return;
        }

        // Verificarea prezenței unei litere majuscule
        Pattern pattern = Pattern.compile("^[A-Z]");
        Matcher matcher = pattern.matcher(parola);
        if (!matcher.find()) {
            System.out.println("Parolă invalidă: Parola trebuie să înceapă cu o literă mare.");
            return;
        }

        // Verificarea prezenței unui caracter special
        pattern = Pattern.compile("[^a-zA-Z0-9]");
        matcher = pattern.matcher(parola);
        if (!matcher.find()) {
            System.out.println("Parolă invalidă: Parola trebuie să conțină cel puțin un caracter special.");
            return;
        }

        // Parola respectă toate cerințele
        System.out.println("Parolă validă.");

        //// EXERCITIUL 22222222222222222

        String str = " Este o umbrelă";
        String[] Cuvinte = str.split(" ");
        String mic = Cuvinte[0];
        String mare = Cuvinte[0];

        for (int i = 1; i < Cuvinte.length; i++) {
            if (Cuvinte[i].length() < mic.length()) {
                mic = Cuvinte[i];
            }
            if (Cuvinte[i].length() > mare.length()) {
                mare = Cuvinte[i];
            }
        }

        System.out.println("Cel mai mic cuvânt: " + mic);
        System.out.println("Cel mai mare cuvânt: " + mare);

    }
}