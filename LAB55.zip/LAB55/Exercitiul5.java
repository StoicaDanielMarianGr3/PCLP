import java.util.Scanner;

public class Exercitiul5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduceti o propozitie:");
        String propozitie = scanner.nextLine();
        System.out.println("Introduceti subsirul care va fi inlocuit:");
        String vechiulSubsir = scanner.nextLine();
        System.out.println("Introduceti noul subsir:");
        String noulSubsir = scanner.nextLine();
        scanner.close();

        // Inlocuirea subsirului
        String propozitieModificata = propozitie.replaceAll(vechiulSubsir, noulSubsir);

        // Afisarea noii propozitii
        System.out.println("Propozitia modificata: " + propozitieModificata);
    }
}
