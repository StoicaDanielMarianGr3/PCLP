import java.util.Scanner;
import java.util.Random;

public class Main {

    // EXERCITIUL 1

    public static void main(String[] args) {

        int Nr;
        Scanner intrare1 = new Scanner(System.in);
        Nr = intrare1.nextInt();
        if (Nr > 0) {
            System.out.println("Numarul este pozitiv");
        } else {
            System.out.println("Numarul este negativ");
        }

        // EXERCITIUL 2

        int Numar;
        int ZiSaptamana;
        Scanner intrare2 = new Scanner(System.in);
        Numar = intrare2.nextInt();
        System.out.println("Numar citit de la tastatura este:" + Numar);
        Random random1 = new Random();
        ZiSaptamana = random1.nextInt(7) + 1;
        String NumeZi;
        switch (ZiSaptamana) {
            case 1:
                NumeZi = "Luni";
                break;

            case 2:
                NumeZi = "Marti";
                break;

            case 3:
                NumeZi = "Miercuri";
                break;

            case 4:
                NumeZi = "Joi";
                break;

            case 5:
                NumeZi = "Vineri";
                break;

            case 6:
                NumeZi = "Sambata";
                break;

            default:
                NumeZi = "Luni";
                break;
        }
        System.out.print("\nNumarul generat random este " + ZiSaptamana);
        System.out.print("\tIar acest numar reprezinta ziua de " + NumeZi);


        // EXERCITIUL 3
/*
        int Numarr = 1;
        int j;
        int Contor=0;
        int Nre=0;
        for(Numarr = 1 ; Numarr <= 100 ; Numarr++)
        {
            for(j = 1 ; j <= Numarr ; j++){

                if( Numarr % j == 0 )
                {
                    Contor++;
                }
                if (Contor >= 2) System.out.println("nu este prim " +Numarr);
                if (Contor <=2) System.out.println("este prim " +Numarr);

                }

            }
        */

        // EXERCITIUL 4

        int nrex3;
        int SumaEven = 0;
        int SumaOdd = 0;
        Scanner intrare3 = new Scanner(System.in);
        nrex3 = intrare3.nextInt();
        System.out.println("Numarul citit de la tastatura este" + nrex3);

        for (int i = 1; i <= nrex3; i++) {
            if (i % 2 == 0) {
                SumaEven += i;
            } else {
                SumaOdd += i;
            }

        }
        System.out.println("Suma numerelor pare" + SumaEven);
        System.out.println("Suma numerelor impare" + SumaOdd);


        // EXERCITIUL 5

        int Varsta;
        int i;
        int j;
        System.out.println("Introduceti Varsta dumeanoastra:");
        Scanner intrare4 = new Scanner(System.in);
        Varsta = intrare4.nextInt();
        String Concluzie = new String("");
            switch (Varsta) {
                case 1:
                    Concluzie = "Nu ai inca dreptul de a vota";

                case 2:
                    Concluzie = "Nu ai inca dreptul de a vota";

                case 3:
                    Concluzie = "Nu ai inca dreptul de a vota";

                case 4:
                    Concluzie = "Nu ai inca dreptul de a vota";

                case 5:
                    Concluzie = "Nu ai inca dreptul de a vota";

                case 6:
                    Concluzie = "Nu ai inca dreptul de a vota";

                case 7:
                    Concluzie = "Nu ai inca dreptul de a vota";

                case 8:
                    Concluzie = "Nu ai inca dreptul de a vota";

                case 9:
                    Concluzie = "Nu ai inca dreptul de a vota";

                case 10:
                    Concluzie = "Nu ai inca dreptul de a vota";

                case 11:
                    Concluzie = "Nu ai inca dreptul de a vota";

                case 12:
                    Concluzie = "Nu ai inca dreptul de a vota";

                case 13:
                    Concluzie = "Nu ai inca dreptul de a vota";

                case 14:
                    Concluzie = "Nu ai inca dreptul de a vota";

                case 15:
                    Concluzie = "Nu ai inca dreptul de a vota";

                case 16:
                    Concluzie = "Nu ai inca dreptul de a vota";

                case 17:
                    Concluzie = "Nu ai inca dreptul de a vota";
                    break;

                default :
                    Concluzie = "Ai dreptul de a vota";


            }
        System.out.println("  " + Concluzie);



    }



    }

