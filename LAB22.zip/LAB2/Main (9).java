import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        float fahrenheit;
        System.out.println("Introdu gradele fahrenheit pentru tema 1:");
        Scanner intrare= new Scanner(System.in);
        fahrenheit= intrare.nextFloat();
        float fahrenheitToCelsius= ( fahrenheit - 32)* 5/9;
        System.out.println("Rezultatul din fahrenheit in Celsius este=" + fahrenheitToCelsius);

        int numar1;
        System.out.println("Introdu un numar pentru tema 2:");
        Scanner intrare2= new Scanner(System.in);
        numar1= intrare2.nextInt();
        if (numar1 > 1000) {
            System.exit(0);
        }
        int suma=0;
        while (numar1 > 0){
            suma += numar1 % 10;
            numar1 /= 10;
        }
        System.out.println("Suma cifrelor este=" + suma);

        double numar2;
        double patratulNr;
        double CubulNr;
        double PutereaPatru;
        System.out.println("Introdu un numar pentru tema 3=");
        Scanner intrare3= new Scanner(System.in);
        numar2= intrare3.nextInt();
        patratulNr= numar2 * numar2;
        System.out.println("Patratul nummarului %.2f este=  %.2f "+ patratulNr );
        CubulNr= numar2 * numar2 * numar2;
        System.out.println("Cubul nummarului este=  %.2f " + CubulNr);
        PutereaPatru = numar2 * numar2 * numar2 * numar2;
        System.out.println("Puterea a patra a nummarului este=  %.2f " + PutereaPatru);

        int numar3;
        System.out.println("Introdu primul numar pentru tema 4=");
        Scanner intrare4= new Scanner(System.in);
        numar3= intrare4.nextInt();
        int numar4;
        System.out.println("Introdu al 2 lea numar pentru tema 4=");
        Scanner intrare5= new Scanner(System.in);
        numar4= intrare5.nextInt();

        int sumaa;
        sumaa= numar3 + numar4;
        System.out.println("\nSuma celor 2 numere este=" + sumaa);

        int scadere;
        if( numar3 > numar4)
        {
            scadere= numar3 - numar4;
        }
        else
        {
            scadere= numar4 - numar3;
        }
        System.out.println("\nscaderea celor 2 numere este=" + scadere);

        int aritmetica;
        aritmetica= (numar3 + numar4)/2;
        System.out.println("\nMedia aritmetica a celor 2 numere este=" + aritmetica);

        int maximul;
        if( numar3> numar4)
        {
            maximul=numar3;
            System.out.println("\nMaximul este=" + maximul);
        }
        else
        {
            maximul=numar4;
            System.out.println("\nMaximul este=" + maximul);
        }

        int minim;
        if(numar3 < numar4)
        {
            minim=numar3;
            System.out.println("\nMinimul este= " + minim);
        }
        else
        {
            minim=numar4;
            System.out.println("\nMinimul este= " + minim);

        }
        int numar5;
        System.out.println("Introdu un numar pentru tema 5:");
        Scanner intrare6= new Scanner(System.in);
        numar5= intrare6.nextInt();
        int Nrdesp=0;
        while (numar5 > 0){
            Nrdesp = numar5 % 10;
            System.out.print("\t" + Nrdesp);
            numar5 /= 10;
        }







    }
}